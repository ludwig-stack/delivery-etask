DSI 60 DAY WORK SCHEDULE AND TASK HANDOFF
October 22 through December 20 2026 | America/Los_Angeles

PURPOSE
Load this work schedule into the project system your team has already built.
This package supplies data and staff instructions only. No app changes or loading
have been performed. CSV/JSON compatibility must be mapped by your technical team.

START HERE
1. Wyline reviews the master workbook and team control document. Adopt or adjust
   the proposed handoff cutoffs without moving true original deadlines.
2. Assign real app accounts to owners. Nova names Setter 1/2, shifts, breaks and
   morning coverage. Nic/Maseeha rows are client handoff requests, not staff shifts.
3. Review Ali/Chester's proposed support duties and 2.5 h/week allocation separately.
   Keep the 80 proposed support rows inactive/unassigned until Wyline assigns them.
4. Technical staff export/backup existing task definitions AND live progress,
   inspect DSI_Field_Mapping.csv, and map the columns to their actual schema.
5. Load into a staging/draft workspace first. Upsert the 494 core rows by task_id.
   Do not regenerate IDs or overwrite live status, actuals, evidence, accepted
   timestamps, comments/audit history, original deadline or recovery fields.
6. Import/attach the 60-day calendar, 21 gates, 20 social posts and metric definitions.
   Resolve dependency IDs after the initial task pass. Roles/targets are metadata;
   do not accidentally turn every calendar row or social mirror into another task.
7. Review the exact mapped result with Wyline, then load to the existing live
   system using your own supported process. Record the import batch/version.
8. Give each person their 60-date PDF and matching CSV. For dates without an assigned
   task, follow the printed off-duty/preactivation note rather than inventing work.

DATE RULE
Day 1 is Oct 22. Execution ends Dec 16 (Day 56). Dec 17–18 are review/recovery days.
Dec 19–20 are weekend watch only with an individually agreed owner. All 60 dates
appear; there are 40 active dates and 20 off dates (18 weekends plus the proposed
Nov 26–27 holiday break). No new cold enrollments Nov 23–27. The December 16
acquisition cutoff stays in force.

OFFICE CLOCK
Kenneth/Nova 13:00. Wyline/Joey/Dexter 16:00.
Emman/Ludwig/Alvin/Brian/Ali/Chester 17:00.
These are confirmed starts, not confirmed shift ends. Row due times are proposed.
Wyline's proposed 21:45 review/22:00 gate uses split DSI blocks within 15 h/week; adopt a
workable closing or delegate arrangement. Earlier versions' morning-team meetings
and 16:45 technical deadlines are superseded by this file schedule.
Customer service 08:00–17:00 requires separately named setters/backup; Nova's 13:00
start does not fill the morning gap. Prepare morning queues the prior staffed
evening. Use America/Los_Angeles, not a fixed UTC-08 offset, across Nov 1.

FILES
DSI_Core_Tasks_494.csv: existing stable IDs with revised responsibilities/timing.
DSI_Proposed_Support_Tasks_80.csv: optional Ali/Chester assignments pending approval.
DSI_Daily_Calendar_and_Targets_60.csv: one row per calendar date and shared targets.
DSI_Roles_and_Hours.csv: all owners, office starts, caps and assignment distinctions.
DSI_Gates_21.csv: independent evidence gates and dependencies.
DSI_Social_Calendar_20.csv: exact 20 original posts and approval/publishing handoffs.
DSI_Metric_Definitions.csv: definitions, source basis and counting rules.
DSI_Weekly_Checkpoints.csv: cumulative team pace, never additive across dates.
DSI_60_Day_Plan.json: full planning dataset with live progress intentionally omitted.
DSI_Field_Mapping.csv: technical mapping guide, not a claim about your app schema.
Staff_Schedules: 15 files with 60 dated rows per person and blank reporting fields.

OUTCOME AND CONTENT RULES
December 16 goal: 40 qualified inquiries, 20 qualified bookings, 15 held conversations,
6 trial cases actually received, 750 verified contacts. These are best-effort goals.
Referral 8 and LinkedIn DM 8 are included within 20; the remaining 4 share other channels.
Wyline owns campaign strategy, LinkedIn media buying and conversion decisions,
and the DSI calendar. Kenneth owns content strategy. Emman owns AI production
and workflow implementation. Nova/setters own qualification and booking movement.
Social mix: 20 originals = 10 Engage / 6 Educate / 4 Promote. Mirrors are not extra originals.
SOC20 on Nov 30 is the proposed extra Engage post. Promotions on Nov 3, Nov 17,
Dec 1 and Dec 15 are 14 days apart. The first 12 originals retain 6 Engage / 4 Educate / 2 Promote.
Ads stay at $0 until written spending approval and tracking/routing acceptance.
The source proposal caps spending at $15/day and $450 total; stop at $300 with
0 attributed bookings. One booking at $300 requires review. Media-buying AI
may assist, but may not approve its own spending.

DAILY REPORT AND RESCUE
Owner records output/KPI, evidence link/CQL ID, status, blocker/impact, help needed,
next owner/date and any recovery request. Unknown stays blank; observed zero is 0.
Review is not completion. Only an authorized human accepts with evidence. Wyline
assigns rescue when blocked; keep the original due date and add a recovery date.
A date advancing never silently accepts unfinished work. No sensitive patient
data belongs in task evidence; use approved CQL links/record IDs.

IMPORT ACCEPTANCE CHECK
60 calendar dates Oct 22–Dec 20; 494 core task IDs; 80 proposed rows separated; 15 roles;
21 gate IDs; 20 social IDs with 10/6/4 mix; no orphan dependency; no task before office
start; correct PDT/PST timestamps; no duplicate task on repeat import; existing
progress preserved; dates/owner/evidence/report visible in the staff view.
Check Oct 22, Nov 2, Nov 25, Nov 26, Dec 16 and Dec 20. Show Wyline these rows before live load.

AI REPORTS LATER
Future AI actors may submit task ID, output, measured KPI and evidence through
an integration your team implements. Keep actor type and human supervisor visible.
No AI API/integration is installed by this package; human acceptance remains required.
